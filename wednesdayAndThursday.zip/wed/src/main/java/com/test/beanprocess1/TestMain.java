package com.test.beanprocess1;

import com.test.beanprocess.TestConnection;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {
    public static void main(String[] args) {
        ConfigurableApplicationContext context  = new ClassPathXmlApplicationContext("postprocess.xml");
        TestConnection networkMng = (TestConnection) context.getBean("connectionmanager");
        networkMng.readData();
        context.close();
    }}
