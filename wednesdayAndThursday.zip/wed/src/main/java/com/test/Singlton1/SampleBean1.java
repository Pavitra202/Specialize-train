package com.test.Singlton1;

public class SampleBean1 {




    public SampleBean1()
    {
        System.out.println("Sample Bean instance is created......");
    }
}