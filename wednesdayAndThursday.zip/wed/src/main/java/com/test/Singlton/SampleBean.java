package com.test.Singlton;

public class SampleBean {




    public SampleBean()
    {
        System.out.println("Sample Bean instance is created......");
    }
}