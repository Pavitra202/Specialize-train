package com.test.collection;

public class ProductDetailBean {
}
