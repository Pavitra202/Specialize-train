// var name="Thanu";

function abc(){
    var fruits=["apple","banana","orange","grapes","gauva"]
    let index;
    for( index=0;index<fruits.length;index++){
        var element =fruits[index];
        console.log(element);
        // console.log(fruits);
        // console.log(index);

    }
    console.log(element);
    console.log(fruits);
    console.log(index)

}
abc();

console.log('Template String');

var message=`This
                 is a
                  Message`;
console.log(message);
var a=1;
var b=2;
console.log(`${a+b}`);