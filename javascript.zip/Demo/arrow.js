function abc(){
    console.log('hello')
}
abc();

var xyz=(x,y)=>{
    // var a=10;
    // var b=10;
    console.log(`the result is ${x+y}`)
    return x+y;
}
console.log(xyz(10,20));

// function add(x){
//     var a=x;
//     console.log(a);
// }
// add(xyz();)