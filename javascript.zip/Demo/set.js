class abc{
    constructor(){
        // setTimeout(function name(params){
            setTimeout( () =>{
            console.log('Hello this is SetTimeout function');
        },5000)
    }
}

var a=new abc();