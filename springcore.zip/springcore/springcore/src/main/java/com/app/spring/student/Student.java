package com.app.spring.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component

public class Student {
	@Autowired
	@Qualifier("maths")
	Teacher teach;
	
	@Autowired
	@Qualifier("Social")
	Teacher tech;
	
	
	public void Teacherdetails() {
		teach.name();
		teach.teach();
		tech.name();
		tech.teach();
		
	}

}
