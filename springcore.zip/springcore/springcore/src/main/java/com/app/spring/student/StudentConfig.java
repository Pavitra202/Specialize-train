package com.app.spring.student;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.app.spring.student")
public class StudentConfig {
	

}
