package com.app.spring.student;

public class Maths implements Teacher {

	public void name() {
		System.out.println("Teacher is Thanu");
		
	}

	public void teach() {
		System.out.println(" Thanu teaches Maths");
		
	}

}
