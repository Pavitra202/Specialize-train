package com.app.spring.student;

public interface Teacher {

	public void name();
	public void teach();
	

}
