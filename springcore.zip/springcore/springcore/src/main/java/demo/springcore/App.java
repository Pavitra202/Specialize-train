package demo.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.app.spring.student.Student;
import com.app.spring.student.StudentConfig;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(StudentConfig.class);
//        Student student=(Student)context.getBean("student");
//        student.details();
////        or
//        Student stud= context.getBean("student",Student.class);
//        stud.details();
////      or
//      context.getBean("student",Student.class).details();
        context.getBean("stud",Student.class).Teacherdetails();
        
        
    }
}
