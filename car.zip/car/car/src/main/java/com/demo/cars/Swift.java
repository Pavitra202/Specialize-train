package com.demo.cars;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
public class Swift extends Cars {
	public void demo() {
		System.out.println(" Hi its me Swift !");
	}
		

	}
	


