package com.demo.cars;

import org.springframework.stereotype.Component;

@Component
public class Bmw extends Cars{
	public void demo() {
		System.out.println(" Hi its me BMW !");
	}
					
			

	}


