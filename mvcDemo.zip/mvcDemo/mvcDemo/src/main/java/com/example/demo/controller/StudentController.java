package com.example.demo.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;



import com.example.demo.EmpService;
import com.example.demo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;



import java.util.List;



@Controller
public class StudentController {



	@Autowired
	EmpService service;



// @RequestMapping("/")
// public String dem()
// {
// return "index.jsp";
// }




	@RequestMapping(value="/save" ,method= RequestMethod.POST)
	public ModelAndView empSave(ModelAndView mv, Employee emp)
	{
		mv.setViewName("redirect:/");
		service.saveEmp(emp);
		return mv;
	}
	@RequestMapping("/")
	public ModelAndView dem(ModelAndView mv)
	{
		mv.setViewName("index.jsp");
		List<Employee> list=service.getEmployees();
		mv.addObject("all",list);
		return mv;
	}
	@RequestMapping("/delete/{id}")
	public ModelAndView deleteEmp(@PathVariable("id") int id, ModelAndView mv , Employee emp)
	{
		mv.setViewName("redirect:/");
		service.deleteEmp(id);
		return mv;
	}
	@RequestMapping(value = "/update")
	public ModelAndView UpdateEmp(@RequestParam("id") int id,ModelAndView mv){
		mv.setViewName("update.jsp");
		mv.addObject("id",id);
		return mv;
	}


}